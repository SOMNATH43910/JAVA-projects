package employee.com.emp;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.*;

public class EmpController {

    @FXML private ComboBox<String> searchTypeBox;
    @FXML private TextField searchField;
    @FXML private TextArea resultArea;

    private final Map<Integer, Employee> employeeMap = new HashMap<>();
    private final Map<Character, String> desigMap = new HashMap<>();
    private final Map<Character, Integer> daMap = new HashMap<>();

    @FXML
    public void initialize() {
        // Sample employees
        employeeMap.put(1001, new Employee(1001, "Ashish", "R&D", 'e', 20000, 8000, 3000));
        employeeMap.put(1002, new Employee(1002, "Sushma", "PM", 'c', 30000, 12000, 9000));
        employeeMap.put(1003, new Employee(1003, "Rahul", "Acct", 'k', 10000, 8000, 1000));
        employeeMap.put(1004, new Employee(1004, "Chahat", "Front Desk", 'r', 12000, 6000, 2000));
        employeeMap.put(1005, new Employee(1005, "Ranjan", "Engg", 'm', 25000, 10000, 20000));
        employeeMap.put(1006, new Employee(1006, "Suman", "Manufacturing", 'e', 23000, 9000, 4400));
        employeeMap.put(1007, new Employee(1007, "Tanmay", "PM", 'c', 29000, 12000, 10000));

        // Designation Maps
        desigMap.put('e', "Engineer");
        desigMap.put('c', "Consultant");
        desigMap.put('k', "Clerk");
        desigMap.put('r', "Receptionist");
        desigMap.put('m', "Manager");

        daMap.put('e', 20000);
        daMap.put('c', 32000);
        daMap.put('k', 12000);
        daMap.put('r', 15000);
        daMap.put('m', 40000);

        searchTypeBox.getItems().addAll("ID", "Name", "Designation");
        searchTypeBox.getSelectionModel().selectFirst();
    }

    @FXML
    public void handleSearch() {
        String type = searchTypeBox.getValue();
        String input = searchField.getText().trim().toLowerCase();
        StringBuilder result = new StringBuilder();
        boolean found = false;

        for (Employee emp : employeeMap.values()) {
            String name = emp.name.toLowerCase();
            String desig = desigMap.get(emp.desigCode);
            String dept = emp.department.toLowerCase();

            boolean matches = switch (type) {
                case "ID" -> String.valueOf(emp.empNo).equals(input);
                case "Name" -> name.contains(input);
                case "Designation" -> desig.toLowerCase().contains(input);
                default -> false;
            };

            if (matches) {
                found = true;
                int salary = emp.basic + emp.hra + daMap.get(emp.desigCode) - emp.it;
                result.append("🔹 ID: ").append(emp.empNo)
                        .append("\n👤 Name: ").append(emp.name)
                        .append("\n🏢 Dept: ").append(emp.department)
                        .append("\n🎓 Designation: ").append(desig)
                        .append("\n💸 Salary: ₹").append(salary)
                        .append("\n----------------------------\n");
            }
        }

        if (found) resultArea.setText(result.toString());
        else resultArea.setText("❌ No employee found for \"" + input + "\"");
    }
}
