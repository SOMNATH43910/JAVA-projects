package employee.com.emp;

public class Employee {
    public int empNo;
    public String name, department;
    public char desigCode;
    public int basic, hra, it;

    public Employee(int empNo, String name, String department, char desigCode, int basic, int hra, int it) {
        this.empNo = empNo;
        this.name = name;
        this.department = department;
        this.desigCode = desigCode;
        this.basic = basic;
        this.hra = hra;
        this.it = it;
    }
}
