package lms;

import lms.service.AuthService;

import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        AuthService authService = new AuthService();
        int choice;

        while (true) {
            System.out.println("========================================");
            System.out.println("  📚 Wlc LIBRARY MANAGEMENT SYSTEM  🪪  ");
            System.out.println("========================================");
            System.out.println("          How Can Help You💬");
            System.out.println(" ");
            System.out.println("1. 👨‍💼 Admin Login");
            System.out.println("========================================");
            System.out.println("2. 👨‍🎓 Student Login");
            System.out.println("========================================");
            System.out.println("3. 📇 Register New Admin");
            System.out.println("========================================");
            System.out.println("4. 🔁 Forgot Admin Password");
            System.out.println("========================================");
            System.out.println("5. 🔁 Forgot Student Password");
            System.out.println("========================================");
            System.out.println("6. ❌ Exit");
            System.out.println("========================================");
            System.out.print("🔍 Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> authService.adminLogin(sc);
                case 2 -> authService.studentLogin(sc);
                case 3 -> authService.registerAdmin(sc);
                case 4 -> authService.forgotAdminPassword(sc);
                case 5 -> authService.forgotStudentPassword(sc);
                case 6 -> {
                    System.out.println("🛑 Exiting LMS... Thank you!");
                    return;
                }
                default -> System.out.println("❌ Invalid choice. Please try again.");
            }
        }
    }
}
