package lms.dao;

import lms.util.DBUtil;

import java.sql.*;
import java.util.UUID;

public class StudentDAO {

    public static boolean registerStudent(
            String name, String dob, String gender,
            String presentAddress, String permanentAddress,
            String phone, String email) {

        String userId = "SID" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        String libCard = "LIB" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        String password = "pass" + userId.substring(3);

        try (Connection conn=DBUtil.getConnection()) {

            String userSQL="INSERT INTO UserCredentials (UserType, UserID, Password, LoginStatus) VALUES (?, ?, ?, ?)";
            PreparedStatement userStmt = conn.prepareStatement(userSQL);
            userStmt.setString(1, "Student");
            userStmt.setString(2, userId);
            userStmt.setString(3, password);
            userStmt.setString(4, "Active");

            String profileSQL = "INSERT INTO StudentProfile (UserID, Name, DOB, Gender, PresentAddress,"
                    +"PermanentAddress, PhoneNumber, EmailID, LibraryCardNum) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement profileStmt = conn.prepareStatement(profileSQL);
            profileStmt.setString(1, userId);
            profileStmt.setString(2, name);
            profileStmt.setDate(3, Date.valueOf(dob));
            profileStmt.setString(4, gender);
            profileStmt.setString(5, presentAddress);
            profileStmt.setString(6, permanentAddress);
            profileStmt.setString(7, phone);
            profileStmt.setString(8, email);
            profileStmt.setString(9, libCard);

            int rows1 = userStmt.executeUpdate();
            int rows2 = profileStmt.executeUpdate();

            System.out.println("🆔 Login ID: " + userId);
            System.out.println("🔑 Password: " + password);
            System.out.println("🎫 Library Card Number: " + libCard);

            return rows1 > 0 && rows2 > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void viewAllStudents() {
        String sql = "SELECT Name, UserID, EmailID, LibraryCardNum FROM StudentProfile";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            ResultSet rs = stmt.executeQuery();
            System.out.println("\n========== All Students ==========");

            while (rs.next()) {
                System.out.println("🔍:Name          : " + rs.getString("Name"));
                System.out.println("🔐:Login ID      : " + rs.getString("UserID"));
                System.out.println("📧:Email         : " + rs.getString("EmailID"));
                System.out.println("🪪: Library Card  : " + rs.getString("LibraryCardNum"));
                System.out.println("----------------------------------");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
