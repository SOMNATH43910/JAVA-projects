package lms.dao;

import lms.util.DBUtil;
import java.sql.*;

public class AuthDAO {

    public static boolean validateAdmin(String username, String password) {
        String sql = "SELECT * FROM UserCredentials WHERE UserType = 'Admin' AND UserID = ? AND Password = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean validateStudent(String username, String password) {
        String sql = "SELECT * FROM UserCredentials WHERE UserType = 'Student' AND UserID = ? AND Password = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean registerAdmin(String empId, String name, String email, String username, String password) {
        String userInsert = "INSERT INTO UserCredentials (UserType, UserID, Password, LoginStatus) VALUES (?, ?, ?, ?)";
        String profileInsert = "INSERT INTO AdminProfile (UserID, Name, EmployeeID, EmailID) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement psUser = conn.prepareStatement(userInsert);
            PreparedStatement psProfile = conn.prepareStatement(profileInsert);

            psUser.setString(1, "Admin");
            psUser.setString(2, username);
            psUser.setString(3, password);
            psUser.setString(4, "Active");

            psProfile.setString(1, username);
            psProfile.setString(2, name);
            psProfile.setString(3, empId);
            psProfile.setString(4, email);

            int rows1 = psUser.executeUpdate();
            int rows2 = psProfile.executeUpdate();

            return rows1 > 0 && rows2 > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean resetAdminPassword(String email, String empId, String newPassword) {
        String getUserSql = "SELECT UserID FROM AdminProfile WHERE EmailID = ? AND EmployeeID = ?";
        String updatePassSql = "UPDATE UserCredentials SET Password = ? WHERE UserID = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement getUserStmt = conn.prepareStatement(getUserSql)) {

            getUserStmt.setString(1, email);
            getUserStmt.setString(2, empId);
            ResultSet rs = getUserStmt.executeQuery();

            if (rs.next()) {
                String userId = rs.getString("UserID");

                try (PreparedStatement updateStmt = conn.prepareStatement(updatePassSql)) {
                    updateStmt.setString(1, newPassword);
                    updateStmt.setString(2, userId);
                    return updateStmt.executeUpdate() > 0;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean resetStudentPassword(String email, String dob, String newPassword) {
        String getUserSql = "SELECT UserID FROM StudentProfile WHERE EmailID = ? AND DOB = ?";
        String updatePassSql = "UPDATE UserCredentials SET Password = ? WHERE UserID = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement getUserStmt = conn.prepareStatement(getUserSql)) {

            getUserStmt.setString(1, email);
            getUserStmt.setDate(2, Date.valueOf(dob));
            ResultSet rs = getUserStmt.executeQuery();

            if (rs.next()) {
                String userId = rs.getString("UserID");

                try (PreparedStatement updateStmt = conn.prepareStatement(updatePassSql)) {
                    updateStmt.setString(1, newPassword);
                    updateStmt.setString(2, userId);
                    return updateStmt.executeUpdate() > 0;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
