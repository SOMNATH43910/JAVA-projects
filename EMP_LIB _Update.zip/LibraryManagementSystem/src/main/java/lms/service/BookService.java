package lms.service;

import lms.dao.BookDAO;

import java.util.List;
import java.util.Scanner;

public class BookService {

    private static final Scanner sc = new Scanner(System.in);

    public static void deleteBook() {
        System.out.print("🆔 Enter Book ID to delete: ");
        String bookId = sc.nextLine();

        boolean success = BookDAO.deleteBookById(bookId);

        if (success) {
            System.out.println("✅ Book deleted successfully.");
        } else {
            System.out.println("❌ Failed to delete book. Check Book ID.");
        }
    }

    public static void searchBook() {
        System.out.print("Enter keyword (ID/Title/Author/Class/Subject): ");
        String keyword = sc.nextLine();

        List<String> results = BookDAO.searchBook(keyword);

        if (results.isEmpty()) {
            System.out.println("❌ No books found matching your criteria.");
        } else {
            System.out.println("📚 Matching Books:");
            results.forEach(System.out::println);
        }
    }

    public static void viewAllBooks() {
        List<String> books = BookDAO.getAllBooks();

        if (books.isEmpty()) {
            System.out.println("📚 No books available in the library.");
        } else {
            System.out.println("======= All Books =======");
            books.forEach(System.out::println);
        }
    }
}
