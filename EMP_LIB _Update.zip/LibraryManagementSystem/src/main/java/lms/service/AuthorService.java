package lms.service;

import lms.dao.AuthorDAO;
import java.util.List;

public class AuthorService {

    public static void deleteAuthor(String authorId) {
        boolean success = AuthorDAO.deleteAuthorById(authorId);
        if (success) {
            System.out.println("✅ Author deleted successfully. 🚮");
        } else {
            System.out.println("❌ Author not found or could not be deleted.👀");
        }
    }

    public static List<String> viewAllAuthors() {
        return AuthorDAO.viewAllAuthors();
    }
}
