package lms.service;

import lms.dao.StudentDAO;
import java.util.Scanner;

public class StudentService {

    public static void registerStudent() {
        Scanner sc = new Scanner(System.in);
        System.out.println("======= Register New Student =======");

        System.out.print("📇 Enter Full Name: ");
        String name = sc.nextLine();

        System.out.print("⎘ Enter DOB (yyyy-mm-dd): ");
        String dob = sc.nextLine();

        System.out.print("👤 Enter Gender (Male/Female/Other): ");
        String gender = sc.nextLine();

        System.out.print("📍 Enter Present Address: ");
        String presentAddress = sc.nextLine();

        System.out.print("🏡 Enter Permanent Address: ");
        String permanentAddress = sc.nextLine();

        System.out.print("📞  Enter Phone Number: ");
        String phone = sc.nextLine();

        System.out.print("📧 Enter Email ID: ");
        String email = sc.nextLine();

        boolean result = StudentDAO.registerStudent(name, dob, gender, presentAddress, permanentAddress, phone, email);

        if (result) {
            System.out.println("✅ Student registered successfully!👨🏻‍🎓");
        } else {
            System.out.println("❌ Registration failed. pls try Again🔄");
        }
    }

    public static void viewAllStudents() {
        StudentDAO.viewAllStudents();
    }
}
