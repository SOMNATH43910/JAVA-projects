package lms.service;

import lms.dao.AuthDAO;
import lms.ui.AdminDashboard;
import java.util.Scanner;

public class AuthService {

    public void adminLogin(Scanner sc) {
        System.out.print(" 🔐 Enter Admin Username: ");
        String username = sc.nextLine();

        System.out.print("🫆 Enter Admin Password: ");
        String password = sc.nextLine();

        boolean isValid = AuthDAO.validateAdmin(username, password);

        if (isValid) {
            System.out.println("✅ Login Successful! Welcome Admin.");
            AdminDashboard.show();
        } else {
            System.out.println("❌ Invalid admin credentials.");
        }
    }

    public void studentLogin(Scanner sc) {
        System.out.print(" 🆔 Enter Student Username: ");
        String username = sc.nextLine();

        System.out.print("🫆 Enter Password: ");
        String password = sc.nextLine();

        boolean isValid = AuthDAO.validateStudent(username, password);

        if (isValid) {
            System.out.println("✅ Login Successful! Welcome Student.👨‍🎓");
        } else {
            System.out.println("❌ Invalid student credentials. 🪪");
        }
    }

    public void registerAdmin(Scanner sc) {
        System.out.println("\n======= Register New Admin =======");

        System.out.print("Enter Name       : ");
        String name = sc.nextLine();

        System.out.print("Enter Email ID   : ");
        String email = sc.nextLine();

        System.out.print("Enter Username   : ");
        String username = sc.nextLine();

        System.out.print("Enter Password   : ");
        String password = sc.nextLine();

        System.out.print("Enter Employee ID: ");
        String empId = sc.nextLine();

        boolean success = AuthDAO.registerAdmin(empId, name, email, username, password);

        if (success) {
            System.out.println("✅ Admin registered successfully!");
        } else {
            System.out.println("❌ Failed to register admin. 🔄");
        }
    }
}
