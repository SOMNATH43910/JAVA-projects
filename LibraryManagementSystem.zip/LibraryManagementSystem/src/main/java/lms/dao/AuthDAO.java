package lms.dao;

import lms.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AuthDAO {
    public static boolean validateAdmin(String username, String password) {
        String sql = "SELECT * FROM UserCredentials WHERE UserType = 'Admin' AND UserID = ? AND Password = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean validateStudent(String username, String password) {
        String sql = "SELECT * FROM UserCredentials WHERE UserType = 'Student' AND UserID = ? AND Password = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean registerAdmin(String empId, String name, String email, String username, String password) {
        String userInsert = "INSERT INTO UserCredentials (UserType, UserID, Password, LoginStatus) VALUES (?, ?, ?, ?)";
        String profileInsert = "INSERT INTO AdminProfile (UserID, Name, EmployeeID, EmailID) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement psUser = conn.prepareStatement(userInsert);
            PreparedStatement psProfile = conn.prepareStatement(profileInsert);

            psUser.setString(1, "Admin");
            psUser.setString(2, username);
            psUser.setString(3, password);
            psUser.setString(4, "Active");

            psProfile.setString(1, username);
            psProfile.setString(2, name);
            psProfile.setString(3, empId);
            psProfile.setString(4, email);

            int rows1 = psUser.executeUpdate();
            int rows2 = psProfile.executeUpdate();

            return rows1 > 0 && rows2 > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
