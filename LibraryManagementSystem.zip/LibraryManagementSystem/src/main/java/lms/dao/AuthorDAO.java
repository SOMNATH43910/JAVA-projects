package lms.dao;
import lms.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AuthorDAO {
    public static List<String> viewAllAuthors() {
        List<String> authors = new ArrayList<>();
        String sql = "SELECT * FROM AuthorDetails";

        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {


            while (rs.next()) {
                String line = rs.getString("AuthorId") + " | " +
                        rs.getString("AuthorName") + " | " +
                        rs.getString("AuthEmailID") + " | " +
                        rs.getString("ContactNum");
                authors.add(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return authors;
    }
    public static boolean deleteAuthorById(String authorId) {
        String sql = "DELETE FROM AuthorDetails WHERE AuthorId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, authorId);
            return ps.executeUpdate() > 0;

        } catch (SQLIntegrityConstraintViolationException e) {
            System.out.println("❌ Cannot delete author: books linked to this author still exist.");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
