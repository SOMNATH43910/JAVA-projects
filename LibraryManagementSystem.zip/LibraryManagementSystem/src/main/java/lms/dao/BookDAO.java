package lms.dao;

import lms.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {
    public static boolean deleteBookById(String bookId) {
        String sql = "DELETE FROM BookDetails WHERE BookId = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, bookId);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    public static List<String> searchBook(String keyword) {
        String sql = "SELECT * FROM BookDetails WHERE BookId LIKE ? OR BName LIKE ? OR AuthorId LIKE ? OR Genre LIKE ?";
        List<String> results = new ArrayList<>();

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String wildcard = "%" + keyword + "%";
            for (int i = 1; i <= 4; i++) {
                ps.setString(i, wildcard);
            }

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                results.add(rs.getString("BookId") + " | " +
                        rs.getString("BName") + " | " +
                        rs.getString("AuthorId") + " | " +
                        rs.getString("Genre") + " | " +
                        rs.getInt("Qty") + " copies | ₹" +
                        rs.getDouble("Price"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }
    public static List<String> getAllBooks() {
        String sql = "SELECT * FROM BookDetails";
        List<String> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                list.add(rs.getString("BookId") + " | " +
                        rs.getString("BName") + " | " +
                        rs.getString("AuthorId") + " | " +
                        rs.getString("Genre") + " | " +
                        rs.getInt("Qty") + " copies | ₹" +
                        rs.getDouble("Price"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
