package lms.ui;

import lms.service.StudentService;
import java.util.Scanner;
import lms.service.BookService;
import lms.service.AuthorService;

public class AdminDashboard {

    private static final Scanner sc = new Scanner(System.in);

    public static void show() {
        while (true) {
            System.out.println("========================================");
            System.out.println("   👨‍💼        ADMIN DASHBOARD      🌍    ");
            System.out.println("========================================");
            System.out.println("1.📇: Register Student");
            System.out.println("2.👥: View All Students");
            System.out.println("3.🗑️:Delete Book");
            System.out.println("4.✍🏻:Delete Author");
            System.out.println("5.🔍:Search Book");
            System.out.println("6.📚:View All Books");
            System.out.println("7.👥:View All Authors");
            System.out.println("8.❌:Logout");
            System.out.print("🔍:Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1 -> StudentService.registerStudent();
                case 2 -> StudentService.viewAllStudents();
                case 3 -> BookService.deleteBook();

                case 4 -> {
                    System.out.print("🆔: Enter Author ID to delete: ");
                    String authorId = sc.nextLine();
                    AuthorService.deleteAuthor(authorId);
                }

                case 5 -> BookService.searchBook();
                case 6 -> BookService.viewAllBooks();


                case 7 -> {
                    System.out.println("========================================");
                    System.out.println("   ✍🏻     AUTHOR DETAILS    📖         ");
                    System.out.println("========================================");
                    for (String author : AuthorService.viewAllAuthors()) {
                        System.out.println(author);
                    }
                }
                case 8 -> {
                    System.out.println("👋 Logged out successfully.");
                    return;
                }

                default -> System.out.println("❌ Invalid choice. Try again.");
            }
        }
    }
}
